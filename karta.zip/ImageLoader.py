from pygame import image, Rect


class ImageLoader:
    """
    Класс для загрузки спрайтов сразу для всех объектов
    _______________________
    Атрибуты
    units : объект image из pygame, в который загружаются все картинки существ
    walls : объект image из pygame, в который загружаются все картинки стен
    _______________________
    Методы
    get_sub_image : возвращает часть общего спрайта - спрайт конкретного объекта
    """
    def __init__(self):
        self.units = image.load("units.png")
        self.walls = image.load("walls.png")

    def get_sub_image(self, image_type, left_cor, right_cor):
        """
        возвращает часть общего спрайта - спрайт конкретного объекта
        :param image_type: из какого набора спрайтов нужно взять картинку
        :param left_cor: координаты левого верхнего угла необходимого изображения на общей картинке
        :param right_cor: координаты правого нижнего угла необходимого изображения на общей картинке
        :return: определенный необходимый спрайт
        """
        width = right_cor[0] - left_cor[0]
        height = right_cor[1] - left_cor[1]
        if image_type == 'units':
            return self.units.subsurface(Rect(left_cor, (width, height)))
        else:
            return self.walls.subsurface(Rect(left_cor, (width, height)))

    def get_pacman_image(self):
        left_cor = (175, 0)
        right_cor = (200, 25)
        return [self.get_sub_image('units', left_cor, right_cor)]
