import pygame as pg
import sys
import settings

W = settings.WIDTH
H = settings.HEIGHT

sc = pg.display.set_mode((W, H))
sc.fill((0, 0, 0))

screen = pg.display.set_mode((W, H))
sprite = pg.image.load('proxod.png')
screen.blit(sprite, (20, 20))
pg.quit()


